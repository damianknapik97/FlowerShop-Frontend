package com.dknapik.flowershop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlowerShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
